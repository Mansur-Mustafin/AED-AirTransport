//
// Created by musta on 20.12.2022.
//

#include "Target.h"

string Target::getAirport() {
    return airport;
}

string Target::getAirline() {
    return airline;
}